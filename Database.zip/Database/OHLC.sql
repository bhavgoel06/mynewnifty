/*
This table stores OHLC data. 
This is part of main database.
*/

use algo;

CREATE TABLE `nifty_historical_data_01min` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date` datetime DEFAULT NULL,
  `open` int DEFAULT NULL,
  `high` int DEFAULT NULL,
  `low` int DEFAULT NULL,
  `close` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `date` (`date`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb3;


