/*
Table to store Daily OHLC data
*/
use Algo;

CREATE TABLE `NIFTY_OHLC_Daily` (
  `date` date NOT NULL,
  `open` int DEFAULT NULL,
  `high` int DEFAULT NULL,
  `low` int DEFAULT NULL,
  `close` int DEFAULT NULL,
  PRIMARY KEY (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
