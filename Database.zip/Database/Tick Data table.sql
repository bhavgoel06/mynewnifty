/*
This table stores tick data . This table is part of your main database.
It can be placed either on your local pc/server or on internet.
*/

use Algo;

CREATE TABLE `mastertickdata` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `TDate` date DEFAULT NULL,
  `TTime` time DEFAULT NULL,
  `last_price` decimal(7,2) NOT NULL,
  `instrument_token` int NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
