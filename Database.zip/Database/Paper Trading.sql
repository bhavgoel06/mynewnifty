/*
These are optional tables to play around with API & do paper trading
*/

use Algo;

CREATE TABLE `DailyTradeHistory` (
  `id` int NOT NULL AUTO_INCREMENT,
  `index_name` varchar(45) DEFAULT NULL,
  `index_token` varchar(45) DEFAULT NULL,
  `instrument` varchar(45) DEFAULT NULL,
  `current_qty` int DEFAULT NULL,
  `expiry` date DEFAULT NULL,
  `stop_loss_points` int DEFAULT NULL,
  `repurchase_points` int DEFAULT NULL,
  `direction` varchar(45) DEFAULT NULL,
  `timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  `userid` varchar(45) DEFAULT NULL,
  `initial_qty` int DEFAULT NULL,
  `status` varchar(45) DEFAULT 'open',
  `index_ltp` int DEFAULT NULL,
  `index_stoploss` int DEFAULT NULL,
  `index_repurchase_target` int DEFAULT NULL,
  `m2m` decimal(18,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `fake_zeroda_orders` (
  `order_id` int NOT NULL AUTO_INCREMENT,
  `tradingsymbol` varchar(45) DEFAULT NULL,
  `quantity` decimal(18,2) DEFAULT NULL,
  `exchange` varchar(45) DEFAULT NULL,
  `transaction_type` varchar(45) DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `product` varchar(45) DEFAULT NULL,
  `order_type` varchar(45) DEFAULT NULL,
  `price` decimal(18,2) DEFAULT NULL,
  `stop_loss_trigger_price` decimal(18,2) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `intent` varchar(45) DEFAULT 'Fresh',
  `userid` varchar(45) DEFAULT NULL,
  `StopLossStatus` varchar(45) DEFAULT 'None',
  `remarks` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `fake_zeroda_positions` (
  `tradingsymbol` varchar(45) DEFAULT NULL,
  `exchange` varchar(45) DEFAULT NULL,
  `product` varchar(45) DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `average_price` decimal(18,2) DEFAULT NULL,
  `last_price` decimal(18,2) DEFAULT NULL,
  `m2m` decimal(18,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `fake_zeroda_trades` (
  `trade_id` int NOT NULL AUTO_INCREMENT,
  `order_id` int DEFAULT NULL,
  `exchange` varchar(45) DEFAULT NULL,
  `tradingsymbol` varchar(45) DEFAULT NULL,
  `average_price` decimal(18,2) DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `transaction_type` varchar(45) DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `brokerage` int DEFAULT '90',
  `trade_date` date DEFAULT NULL,
  PRIMARY KEY (`trade_id`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `five_minute_option_strategy` (
  `id` int NOT NULL AUTO_INCREMENT,
  `current_phase` varchar(45) DEFAULT NULL,
  `last_update` datetime DEFAULT NULL,
  `last_sqroff` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;



CREATE TABLE `trade_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date_log` date DEFAULT NULL,
  `module` varchar(45) DEFAULT NULL,
  `activity` varchar(45) DEFAULT NULL,
  `important_data` varchar(255) DEFAULT NULL,
  `priority` int DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb3;
