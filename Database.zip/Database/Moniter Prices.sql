/*
This table is used to Monitor Stock Prices for auto alerts
*/

use Algo;

CREATE TABLE `MonitorStocks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `trading_symbol` varchar(45) DEFAULT NULL,
  `instrument_token` varchar(45) DEFAULT NULL,
  `price` int DEFAULT NULL,
  `targetPrice` int DEFAULT NULL,
  `enabled` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
