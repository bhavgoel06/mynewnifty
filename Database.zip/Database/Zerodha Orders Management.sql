/*
Table to store & monitor orders placed on Zerodha and automatic stop loss order placement & trailing
Part of your Strategy
*/

CREATE TABLE `marketorders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `zerodha_id` varchar(45) DEFAULT NULL,
  `transaction_type` varchar(45) DEFAULT NULL,
  `price_executed` decimal(18,2) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `intent` varchar(45) DEFAULT NULL,
  `limitprice` decimal(18,2) DEFAULT NULL,
  `order_type` varchar(45) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `userid` varchar(45) DEFAULT NULL,
  `instrument` varchar(45) DEFAULT NULL,
  `exchange` varchar(45) DEFAULT NULL,
  `StopLossStatus` varchar(45) DEFAULT 'None',
  `Position` varchar(45) DEFAULT 'None',
  `qty` int NOT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8mb3;