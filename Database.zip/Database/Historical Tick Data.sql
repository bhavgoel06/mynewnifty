/*
Tick Table to store historical data
*/
CREATE TABLE `Tick` (
  `Date` date DEFAULT NULL,
  `Time` time DEFAULT NULL,
  `LTP` decimal(7,2) NOT NULL,
  `LTQ` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
