CREATE TABLE `five_minute_option_strategy` (
  `id` int NOT NULL AUTO_INCREMENT,
  `current_phase` varchar(45) DEFAULT NULL,
  `last_update` datetime DEFAULT NULL,
  `last_sqroff` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
