/*
This table is part of your main database. 
Its used to store details of all the instruments which you can trade on Zerodha.
You can use this table to get instrument token or trading symbol which you can use to place orders or to get LTP
You don't need to populate this table every day. 
You may download this data according to your need like every week or every month.
You may add additional columns as per your requirements.
*/

CREATE TABLE `instruments_zerodha` (
  `instrument_token` bigint DEFAULT NULL,
  `tradingsymbol` text,
  `name` text,
  `last_price` double DEFAULT NULL,
  `expiry` text,
  `strike` double DEFAULT NULL,
  `lot_size` bigint DEFAULT NULL,
  `instrument_type` text,
  `segment` text,
  `exchange` text,
  `margin` bigint DEFAULT NULL,
  `ltp` bigint DEFAULT NULL,
  `open` bigint DEFAULT NULL,
  `low` bigint DEFAULT NULL,
  `high` bigint DEFAULT NULL,
  `close` bigint DEFAULT NULL,
  `sl_points` bigint DEFAULT NULL,
  `profit_points` bigint DEFAULT NULL,
  `purchase_below` bigint DEFAULT NULL,
  `purchase_above` bigint DEFAULT NULL,
  KEY `ix_instruments_zerodha_instrument_token` (`instrument_token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
