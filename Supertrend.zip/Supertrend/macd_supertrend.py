import pandas as pd
import numpy as np
from background.icici import icici
from datetime import datetime, date, timedelta, time
import time as Time
icici = icici()
tickers = ['ADANIENT', 'ADANIPORTS', 'ASIANPAINT', 'TATASTEEL', 'TITAN']
df_tickers = pd.DataFrame(tickers, columns=['symbol'])
global dfTrades
dfTrades = pd.DataFrame(columns=['Stock', 'Action', 'Price', 'TimeStamp'])
import warnings
warnings.filterwarnings('ignore')

def MACD(data, fast_ma_period, slow_ma_period, signal_period):
    data["FMA"] = data['Close'].ewm(span=fast_ma_period).mean()
    data["SMA"] = data['Close'].ewm(span=slow_ma_period).mean()
    data["MACD"] = data["FMA"] - data["SMA"]
    data["Signal"] = data['MACD'].ewm(span=signal_period).mean()
    prv_macd = data["MACD"].iloc[-2]
    prv_signal = data["Signal"].iloc[-2]    
    cur_macd = data["MACD"].iloc[-1]
    cur_signal = data["Signal"].iloc[-1]
    indicator = 'none'
    if cur_macd > cur_signal:
        indicator= 'bullish'
    elif cur_macd < cur_signal:
        indicator = 'bearish'
    return indicator

def get_supertrend(data):
    range_period = 7
    multiplier = 3
    data.High = data.High.astype(float)
    data.Low = data.Low.astype(float)
    data.Close = data.Close.astype(float)
    data['High-Low']=data['High']-data['Low']
    data['High-Previous_Close']=abs(data['High']-data['Close'].shift(1))
    data['Low-Previous_Close']=abs(data['Low']-data['Close'].shift(1))
    data['True_Range']=data[['High-Low','High-Previous_Close','Low-Previous_Close']].max(axis=1,skipna=False)    
    data['ATR'] = data['True_Range'].ewm(com=range_period, min_periods=range_period).mean()
    data['basic_upper_band'] = (data.High + data.Low) / 2 + multiplier * data['ATR']
    data['final_upper_band'] = 0.00
    for i in range(range_period,len(data)):
        if data['Close'][i-1]<=data['final_upper_band'][i-1]:
            data['final_upper_band'].iat[i] = min(data['basic_upper_band'].iat[i],data['final_upper_band'].iat[i-1])
        else:
            data['final_upper_band'].iat[i] = data['basic_upper_band'].iat[i]
    data['basic_lower_band'] = (data.High + data.Low) / 2 - multiplier * data['ATR']
    data['final_lower_band'] = 0.00
    for i in range(range_period,len(data)):
        if data['Close'][i-1]>=data['final_lower_band'][i-1]: 
            data['final_lower_band'].iat[i] = max(data['basic_lower_band'].iat[i],data['final_lower_band'].iat[i-1])
        else: 
            data['final_lower_band'].iat[i] = data['basic_lower_band'].iat[i] 
    data['SuperTrend']=np.nan
    if data['Close'].iat[range_period]<=data['final_upper_band'].iat[range_period]:
        data['SuperTrend'].iat[range_period+1]=data['final_upper_band'].iat[range_period+1]
    else:
        data['SuperTrend'].iat[range_period+1]=data['final_lower_band'].iat[range_period+1]
    for i in range(range_period,len(data)):
        if data['SuperTrend'].iat[i-1]==data['final_upper_band'].iat[i-1] and data['Close'].iat[i]<=data['final_upper_band'].iat[i]:        
            data['SuperTrend'].iat[i]=data['final_upper_band'].iat[i] 
        elif  data['SuperTrend'].iat[i-1]==data['final_upper_band'].iat[i-1] and data['Close'][i]>=data['final_upper_band'].iat[i]:
            data['SuperTrend'].iat[i]=data['final_lower_band'].iat[i]
        elif data['SuperTrend'].iat[i-1]==data['final_lower_band'].iat[i-1] and data['Close'][i]>=data['final_lower_band'].iat[i]:
            data['SuperTrend'].iat[i]=data['final_lower_band'].iat[i] 
        elif data['SuperTrend'].iat[i-1]==data['final_lower_band'][i-1] and data['Close'][i]<=data['final_lower_band'].iat[i]:
            data['SuperTrend'].iat[i]=data['final_upper_band'].iat[i] 
    data.dropna(inplace=True) 
    data['direction'] = np.where(data.Close >= data.SuperTrend, 'bullish','bearish')
    data['up'] = np.where(data.direction == 'bullish', data.SuperTrend, np.nan)
    data['down'] = np.where(data.direction == 'bearish', data.SuperTrend, np.nan)
    data['change'] = np.where((data.direction == 'bullish') & (data.direction.shift(1) == 'bearish'), 1, 0)
    data['change'] = np.where((data.direction == 'bearish') & (data.direction.shift(1) == 'bullish'), -1, data.change)   
    data['change'] = data['change'].astype(int)  
    return data.direction.iloc[-1], data.change.iloc[-1]


def main():
    global dfTrades
    dfpositions = pd.DataFrame(columns=['asset','position'])
    dfpositions.to_csv('positions.csv', index=False) #clear file
    #dfpositions = pd.read_csv('positions.csv')
    cur_date = icici.getCurrentDate()
    prv_date_recent = cur_date - timedelta(days=4)
    starttime = time(9, 16, 0)
    inittime = time(11, 30, 0)
    endtime = time(15, 10, 0)
    CurrentDateTime = icici.getCurrentDateTime()
    CurrentTime = time(CurrentDateTime.hour, CurrentDateTime.minute, CurrentDateTime.second)
    CurrentDate = icici.getCurrentDateTime()
    qty = 1
    initiated = 0
    while True:
        CurrentDateTime = icici.getCurrentDateTime()
        CurrentTime = time(CurrentDateTime.hour, CurrentDateTime.minute, CurrentDateTime.second)
        print(CurrentDateTime.strftime("%d-%b %I:%M:%p"))
        if CurrentTime < starttime:
            Time.sleep(5)
            continue
        elif CurrentTime >= endtime:
            print('clear position', len(dfpositions))
            for i in range(0,len(dfpositions)):
                position = dfpositions.position.iloc[i].astype(int)
                asset = dfpositions.asset.iloc[i]
                print(i, asset, position)
                position = None
                if (dfpositions['asset'] == asset).sum() > 0:
                    pos = dfpositions[dfpositions['asset'] == asset].position.iloc[0].astype(int)
                else:
                    pos = 0
                if pos == -1:
                    position = 'Short'
                elif pos == 1:
                    position = 'Long'
                elif pos == 0:
                    position = None
                else:
                    position = 'SquareOff'     
                if position == 'Long':
                    orderid = icici.PlaceSELLOrderMarketNSE(asset, qty)
                    if orderid != -1:
                        print(CurrentDateTime.strftime("%d-%b %I:%M:%p"), asset, "Square Off, OrderID:", orderid)
                        position = 'Square Off'
                        if (dfpositions['asset'] == asset).sum() > 0:
                            dfpositions['position'] = np.where(dfpositions.asset == asset, 2, dfpositions.position)
                elif position == 'Short':
                    orderid = icici.PlaceBuyOrderMarketNSE(asset, qty)
                    if orderid != -1:
                        print(CurrentDateTime.strftime("%d-%b %I:%M:%p"), asset, "Square Off, OrderID:", orderid)
                        position = 'Square Off'
                        if (dfpositions['asset'] == asset).sum() > 0:
                            dfpositions['position'] = np.where(dfpositions.asset == asset, 2, dfpositions.position)
            print('Finishing for the day')
            break
        if len(dfpositions) == 0:
            dfpositions = pd.DataFrame(tickers, columns=['asset'])
            dfpositions['position'] = 0
        else:
            for i in range(0,len(tickers)):
                item = tickers[i]
                if len(dfpositions.query("asset == '" + str(item) + "'")) == 0:
                    dfpositions.loc[len(dfpositions.index)] = [str(item), 0]

        for i in range(0,len(dfpositions)):
            symbol = dfpositions.asset.iloc[i]
            to_date_iso = CurrentDateTime.isoformat()[:19] + '.000Z'
            ohlc = icici.download_ohlc_intraday(str(prv_date_recent), to_date_iso, symbol, '1minute')
            df_ohlc = ohlc[['Date', 'Open', 'High', 'Low', 'Close']]
            if len(ohlc) == 0:
                continue            
            macd_direction = MACD(ohlc, fast_ma_period=12, slow_ma_period=26, signal_period=9)  
            ltp = ohlc.Close.iloc[-1]
            supertrend_direction, change = get_supertrend(ohlc)
            position = None
            if (dfpositions['asset'] == symbol).sum() > 0:
                pos = dfpositions[dfpositions['asset'] == symbol].position.iloc[0].astype(int)
            else:
                pos = 0
            if pos == -1:
                position = 'Short'
            elif pos == 1:
                position = 'Long'
            elif pos == 0:
                position = None
            else:
                position = 'SquareOff'
            if position == None and CurrentTime <= inittime:
                if (macd_direction == 'bearish') and (supertrend_direction == 'bearish'):
                    dfTrades.loc[len(dfTrades.index)] = [symbol, 'SELL', ltp, str(CurrentDateTime.strftime("%d-%b %I:%M:%p"))]
                    orderid = icici.PlaceSELLOrderMarketNSE(symbol, qty)
                    if orderid != -1:
                        #print(CurrentDateTime.strftime("%d-%b %I:%M:%p"), symbol, "Short, OrderID:", orderid)
                        position = 'Short'
                        if (dfpositions['asset'] == symbol).sum() > 0:
                            dfpositions['position'] = np.where(dfpositions.asset == symbol, -1, dfpositions.position)
                        else:
                            dfpositions.loc[len(dfpositions.index)] = [symbol, -1]
                elif (macd_direction == 'bullish') and (supertrend_direction == 'bullish'):
                    dfTrades.loc[len(dfTrades.index)] = [symbol, 'BUY', ltp, str(CurrentDateTime.strftime("%d-%b %I:%M:%p"))]
                    orderid = icici.PlaceBuyOrderMarketNSE(symbol, qty)
                    if orderid != -1:
                        #print(CurrentDateTime.strftime("%d-%b %I:%M:%p"), symbol, "Go Long, OrderID:", orderid)
                        position = 'Long'
                        if (dfpositions['asset'] == symbol).sum() > 0:
                            dfpositions['position'] = np.where(dfpositions.asset == symbol, 1, dfpositions.position)
                        else:
                            dfpositions.loc[len(dfpositions.index)] = [symbol, 1]
            elif position == 'Long':
                if (macd_direction == 'bearish') and (supertrend_direction == 'bearish'):                
                    #Square off position
                    dfTrades.loc[len(dfTrades.index)] = [symbol, 'SELL', ltp, str(CurrentDateTime.strftime("%d-%b %I:%M:%p"))]
                    orderid = icici.PlaceSELLOrderMarketNSE(symbol, qty)
                    if orderid != -1:
                        print(CurrentDateTime.strftime("%d-%b %I:%M:%p"),symbol, "Square Off, OrderID:", orderid)
                        position = 'SquareOff'                
                        dfpositions['position'] = np.where(dfpositions.asset == symbol, 0, dfpositions.position)
                        print('Positions\n', dfpositions)
                    # New Short
                    dfTrades.loc[len(dfTrades.index)] = [symbol, 'SELL', ltp, str(CurrentDateTime.strftime("%d-%b %I:%M:%p"))]
                    orderid = icici.PlaceSELLOrderMarketNSE(symbol, qty)
                    if orderid != -1:
                        print(CurrentDateTime.strftime("%d-%b %I:%M:%p"), symbol, "Short, OrderID:", orderid)
                        position = 'Short'
                        if (dfpositions['asset'] == symbol).sum() > 0:
                            dfpositions['position'] = np.where(dfpositions.asset == symbol, -1, dfpositions.position)
                        else:
                            dfpositions.loc[len(dfpositions.index)] = [symbol, -1]
                elif macd_direction != supertrend_direction:
                    print('position: ', position, ' macd_direction != supertrend_direction')
                    #Square off position
                    dfTrades.loc[len(dfTrades.index)] = [symbol, 'SELL', ltp, str(CurrentDateTime.strftime("%d-%b %I:%M:%p"))]
                    orderid = icici.PlaceSELLOrderMarketNSE(symbol, qty)
                    if orderid != -1:
                        print(CurrentDateTime.strftime("%d-%b %I:%M:%p"),symbol, "Square Off, OrderID:", orderid)
                        position = 'SquareOff'                
                        dfpositions['position'] = np.where(dfpositions.asset == symbol, 0, dfpositions.position)
            elif position == 'Short':
                if (macd_direction == 'bullish') and (supertrend_direction == 'bullish'):
                    #Square off position
                    dfTrades.loc[len(dfTrades.index)] = [symbol, 'BUY', ltp, str(CurrentDateTime.strftime("%d-%b %I:%M:%p"))]
                    orderid = icici.PlaceBuyOrderMarketNSE(symbol, qty)
                    if orderid != -1:
                        print(symbol, "Square Off")
                        position = 'SquareOff'                
                        dfpositions['position'] = np.where(dfpositions.asset == symbol, 0, dfpositions.position)
                    # New Long
                    dfTrades.loc[len(dfTrades.index)] = [symbol, 'BUY', ltp, str(CurrentDateTime.strftime("%d-%b %I:%M:%p"))]
                    orderid = icici.PlaceBuyOrderMarketNSE(symbol, qty)
                    if orderid != -1:
                        #print(CurrentDateTime.strftime("%d-%b %I:%M:%p"), symbol, "Go Long, OrderID:", orderid)
                        position = 'Long'
                        print('sum', (dfpositions['asset'] == symbol).sum())
                        if (dfpositions['asset'] == symbol).sum() > 0:
                            dfpositions['position'] = np.where(dfpositions.asset == symbol, 1, dfpositions.position)
                        else:
                            dfpositions.loc[len(dfpositions.index)] = [symbol, 1]
                elif macd_direction != supertrend_direction:
                    print('position: ', position, ' macd_direction != supertrend_direction')
                    #Square off position
                    dfTrades.loc[len(dfTrades.index)] = [symbol, 'BUY', ltp, str(CurrentDateTime.strftime("%d-%b %I:%M:%p"))]
                    orderid = icici.PlaceBuyOrderMarketNSE(symbol, qty)
                    if orderid != -1:
                        print(symbol, "Square Off")
                        position = 'SquareOff'                
                        dfpositions['position'] = np.where(dfpositions.asset == symbol, 0, dfpositions.position)
        dfpositions.to_csv('positions.csv', index=False)
        initiated = 1
        if len(dfTrades) > 0:
            print('Trades\n', dfTrades)
        dfpos = dfpositions[dfpositions.position != 0]
        print('Positions\n', dfpos)
        Time.sleep(60)
main()

