# Login to Breeze API
import pandas as pd
from breeze_connect import BreezeConnect
from datetime import datetime, date, time
import os
from selenium import webdriver
import time
from pyotp import TOTP
import urllib
class login():

    def __init__(self, force_login=False):
        file = open("background/security_rn.txt", "r")
        keys = file.read().split()  
        self.api_key = keys[0].replace('api_key:','')
        self.key_secret = keys[1].replace('secret:','')
        self.userID = keys[2].replace('user:','')
        self.pwd = keys[3].replace('password:','')
        self.totp_key = keys[4].replace('totp_key:','')
        self.force_login = force_login

    def InitiateICICI(self):
        file = open("background/access.txt", "r")
        keys = file.read().split()
        last_login_date_str = keys[0].replace('date:','')
        token = keys[1].replace('token:','')
        last_login_date = datetime.strptime(last_login_date_str, "%Y-%m-%d").date()
        #print('Last Login:', last_login_date)
        breeze = BreezeConnect(api_key=self.api_key)
        if self.force_login is False and last_login_date == datetime.now().date():
            #print('Access Key Available. Skipping fresh login')            
            try:
                breeze.generate_session(api_secret=self.key_secret, session_token=token)
                #breeze.ws_connect()
                return True, breeze
            except Exception as e:
                print(f"Error during subsequent login to Breeze:{e}")
                return False, None
        else:
            print('Attempting Fresh Login')
            browser = webdriver.Chrome()
            browser.get("https://api.icicidirect.com/apiuser/login?api_key="+urllib.parse.quote_plus(self.api_key))
            browser.implicitly_wait(5)
            username = browser.find_element("xpath", '/html/body/form/div[2]/div/div/div[1]/div[2]/div/div[1]/input')
            password = browser.find_element("xpath", '/html/body/form/div[2]/div/div/div[1]/div[2]/div/div[3]/div/input')             
            username.send_keys(self.userID)
            password.send_keys(self.pwd)
            #Checkbox
            browser.find_element("xpath", '/html/body/form/div[2]/div/div/div[1]/div[2]/div/div[4]/div/input').click()
            # Click Login Button
            browser.find_element("xpath", '/html/body/form/div[2]/div/div/div[1]/div[2]/div/div[5]/input[1]').click()
            time.sleep(2)
            pin = browser.find_element("xpath", '/html/body/form/div[2]/div/div/div[2]/div/div[2]/div[2]/div[3]/div/div[1]/input')
            totp = TOTP(self.totp_key)
            totp_token = totp.now()
            pin.send_keys(totp_token)
            browser.find_element("xpath", '/html/body/form/div[2]/div/div/div[2]/div/div[2]/div[2]/div[4]/input[1]').click()
            time.sleep(2)
            token=browser.current_url.split('apisession=')[1][:8]
            print('token:', token)
            # write in access.txt
            with open('background/access.txt', 'w') as f:
                content = 'date:' + datetime.now().date().strftime("%Y-%m-%d") + '\ntoken:' + str(token)
                f.write(content)
                f.flush()
                print('access token saved to file')
            breeze.generate_session(api_secret=self.key_secret, session_token=token)
            print('Ready to trade')
            return True, breeze

