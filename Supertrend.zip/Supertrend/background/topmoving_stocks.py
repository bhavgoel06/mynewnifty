 # Most Active Securities
import pandas as pd
import datetime
#from nsepy import get_history
#from icici import ICICI
import numpy as np
import warnings
warnings.filterwarnings('ignore')
from nsepython import *
tickers = ['ADANIENT', 'ADANIPORTS', 'APOLLOHOSP', 'ASIANPAINT', 'AXISBANK', 'BAJAJ-AUTO', 'BAJFINANCE', 'BAJAJFINSV', 'BPCL', 'BHARTIARTL', 'CIPLA', 'COALINDIA', 'DIVISLAB', 'DRREDDY', 'EICHERMOT', 'GRASIM', 'HCLTECH', 'HDFCBANK', 'HDFCLIFE', 'HEROMOTOCO', 'HINDALCO', 'HINDUNILVR', 'HDFC', 'ICICIBANK', 'ITC', 'INDUSINDBK', 'INFY', 'JSWSTEEL', 'KOTAKBANK', 'LT', 'M&M', 'MARUTI', 'NTPC', 'NESTLEIND', 'ONGC', 'POWERGRID', 'RELIANCE', 'SBILIFE', 'SBIN', 'SUNPHARMA', 'TCS', 'TATACONSUM', 'TATAMOTORS', 'TATASTEEL', 'TECHM', 'TITAN', 'UPL', 'ULTRACEMCO', 'WIPRO']
df_tickers = pd.DataFrame(tickers, columns=['symbol'])


dfgainers = nse_get_top_gainers()
dflosers = nse_get_top_losers()
dftop = pd.concat([dfgainers, dflosers], axis=0)
dftop.reset_index(inplace=True)   
dftop['pChange'] = abs(dftop['pChange'])
dftop = dftop.sort_values(by=["pChange"], ascending=False)#.head(3)
dftop = dftop[['symbol', 'pChange']]

dftop = pd.merge(dftop, df_tickers, on='symbol')

dftop['symbol'].head(5).tolist()
